while (1):
    print("hello")