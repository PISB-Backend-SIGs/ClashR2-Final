a = input()

print(a)
