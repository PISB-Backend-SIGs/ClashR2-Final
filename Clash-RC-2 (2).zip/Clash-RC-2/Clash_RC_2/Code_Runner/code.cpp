#include<iostream>
 int main(){{


		//write your code here 
		return 0;
}