communicate()
        # stdout2, stderr2 = process