op)
    print(final_op.stdout.decode())
    print(final_op.stderr)