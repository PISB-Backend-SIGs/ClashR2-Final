#include <stdio.h>  
#include <string.h>  
int main()  
{  
    char str[40]; 
    scanf ("%s", str);  
      
    // use strrev() function to reverse a string  
    printf (" \n After the reverse of a string: %s ",str);  
    return 0;  
}  