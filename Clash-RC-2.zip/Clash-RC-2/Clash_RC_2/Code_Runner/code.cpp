#include<iostream>
 int main(){{


		//write your code here 
		cout<<"HVs";
		return 0;
}