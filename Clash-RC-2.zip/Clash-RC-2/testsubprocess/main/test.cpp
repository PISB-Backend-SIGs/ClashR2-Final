#include <iostream>
using namespace std;
int main(){
    while (1)
    {
        cout<<"hell"
    }
    
}